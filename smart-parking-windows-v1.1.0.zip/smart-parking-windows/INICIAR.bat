@echo off
setlocal
cd /d "%~dp0"
title Allus Park - Smart Parking 3D
where node.exe >nul 2>&1
if errorlevel 1 (
  echo Instale o Node.js 24 LTS em https://nodejs.org/
  echo Depois feche esta janela e abra INICIAR.bat novamente.
  pause
  exit /b 1
)
where npm.cmd >nul 2>&1
if errorlevel 1 (
  echo npm nao encontrado. Reinstale o Node.js com as opcoes padrao.
  pause
  exit /b 1
)
node -e "if (Number(process.versions.node.split('.')[0]) < 22) process.exit(1)"
if errorlevel 1 (
  echo Atualize o Node.js para a versao 24 LTS em https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules\.package-lock.json (
  echo Preparando o projeto. A primeira abertura precisa de internet.
  call npm.cmd ci --no-audit --no-fund
  if errorlevel 1 (
    echo Nao foi possivel instalar. Confira a internet e a mensagem acima.
    pause
    exit /b 1
  )
)
echo Abrindo o sistema no navegador. Mantenha esta janela aberta.
echo Para encerrar, pressione Ctrl+C nesta janela.
start "" /b powershell.exe -NoProfile -Command "$url='http://localhost:5173'; for ($i=0; $i -lt 60; $i++) { try { $r=Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 1; if ($r.StatusCode -eq 200 -and $r.Content -match 'Allus Park') { Start-Process $url; break } } catch {}; Start-Sleep -Seconds 1 }"
call npm.cmd run dev -- --port 5173 --strictPort
if errorlevel 1 (
  echo O servidor nao iniciou. Confira a mensagem acima.
  echo Se o sistema ja estiver aberto, acesse http://localhost:5173
  pause
)
