"""Package the application source for Windows; excludes credentials and dependencies."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json

root = Path(__file__).resolve().parents[1]
version = json.loads((root / 'package.json').read_text())['version']
output = root.parent / 'artifacts'
output.mkdir(exist_ok=True)
files = ['package.json', 'package-lock.json', 'index.html', 'vite.config.ts',
         'vitest.config.ts', 'playwright.config.ts', 'tsconfig.json', '.gitignore',
         'README.md', 'INICIAR.bat', 'LEIA-ME-WINDOWS.txt']
paths = [root / name for name in files]
for folder in ['src', 'tests', 'e2e', 'scripts']:
    paths.extend(p for p in (root / folder).rglob('*')
                 if p.is_file() and '__pycache__' not in p.parts)
archive = output / 'smart-parking-windows.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED) as bundle:
    for path in sorted(paths):
        bundle.write(path, Path('smart-parking-windows') / path.relative_to(root))
with ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert json.loads(bundle.read('smart-parking-windows/package.json'))['version'] == version
    assert 'smart-parking-windows/INICIAR.bat' in bundle.namelist()
    print(f'Windows {version}: {len(bundle.namelist())} arquivos, {archive.stat().st_size} bytes')
(output / f'smart-parking-windows-v{version}.zip').write_bytes(archive.read_bytes())
