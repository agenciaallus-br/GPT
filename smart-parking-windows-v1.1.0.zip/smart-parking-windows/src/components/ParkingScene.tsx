import { Suspense, useMemo, useRef, useState, useEffect, Component, type ReactNode } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, ContactShadows, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import type { OrbitControls as OrbitControlsType } from 'three-stdlib';
import { occupant, type Data, type Session, type Slot } from '../domain';
import { dimensions, extents, gate, routeFor, type Layout } from '../layout';
export type View='overview'|'top'|'entry'|'exit';
const statusColor={available:'#30e6a0',occupied:'#fb6478',reserved:'#f6c76a',blocked:'#738096'};
function Box({position,size,color,...props}:{position:[number,number,number];size:[number,number,number];color:string;[key:string]:unknown}){return <mesh position={position} castShadow receiveShadow {...props}><boxGeometry args={size}/><meshStandardMaterial color={color} roughness={.75}/></mesh>}
function Label({position,children,className='scene-label'}:{position:[number,number,number];children:string;className?:string}) {
 const {texture,ratio}=useMemo(()=>{
  const c=document.createElement('canvas'),ctx=c.getContext('2d')!;
  ctx.font='600 48px Inter, sans-serif';const width=Math.ceil(ctx.measureText(children).width)+36;c.width=width;c.height=80;
  ctx.font='600 48px Inter, sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
  const tag=className==='car-tag'||className==='building-label';if(tag){ctx.fillStyle='#142b35';ctx.fillRect(0,0,width,80);ctx.strokeStyle='#7bbaa3';ctx.lineWidth=3;ctx.strokeRect(1,1,width-2,78);}
  ctx.fillStyle=className==='sector-label'?'#9fbdb0':className==='building-label'?'#9ff3ce':'#d5e2dc';ctx.shadowColor='#0008';ctx.shadowBlur=3;ctx.fillText(children,width/2,42);
  return {texture:new THREE.CanvasTexture(c),ratio:width/80};
 },[children,className]);
 useEffect(()=>()=>texture.dispose(),[texture]);
 const height=className==='sector-label'?1.5:className==='building-label'?1.05:className==='car-tag'?1:.58;
 return <sprite position={position} scale={[height*ratio,height,1]} raycast={()=>{}}><spriteMaterial map={texture} transparent depthWrite={false}/></sprite>;
}
function Motorcycle({color}:{color:string}) {return <group name="motorcycle-model">
 {[-.92,.92].map(z=><group key={z} position={[0,.43,z]}><mesh rotation={[0,0,Math.PI/2]} castShadow><cylinderGeometry args={[.43,.43,.2,24]}/><meshStandardMaterial color="#10151c" roughness={.9}/></mesh><mesh rotation={[0,0,Math.PI/2]}><cylinderGeometry args={[.29,.29,.215,16]}/><meshStandardMaterial color="#b6c4cc" metalness={.8} roughness={.25}/></mesh></group>)}
 <Box position={[0,.64,0]} size={[.45,.4,.65]} color="#525e67"/>
 <RoundedBox args={[.58,.46,.8]} position={[0,1,.15]} radius={.18} castShadow><meshStandardMaterial color={color} metalness={.45} roughness={.25}/></RoundedBox>
 <RoundedBox args={[.52,.16,.85]} position={[0,1.12,-.5]} radius={.07} castShadow><meshStandardMaterial color="#14202b"/></RoundedBox>
 {[-.22,.22].map(x=><group key={x}><Box position={[x,.88,.86]} size={[.07,1,.07]} color="#b9c7cf" rotation={[.15,0,0]}/><Box position={[x,.65,-.5]} size={[.06,.07,1.1]} color="#7b8a93" rotation={[.2,0,0]}/></group>)}
 <Box position={[0,1.5,.7]} size={[1,.07,.09]} color="#899da8"/>
 <Box position={[0,1.3,.77]} size={[.08,.45,.08]} color="#899da8"/>
 <mesh position={[0,1.17,1.05]}><sphereGeometry args={[.19,16,12]}/><meshStandardMaterial color="#fff3bf" emissive="#ddd0a4" emissiveIntensity={.4}/></mesh>
 <Box position={[0,1.1,-1.02]} size={[.35,.1,.08]} color="#fb6478"/>
 <Box position={[.34,.55,-.55]} size={[.16,.18,.85]} color="#a8b9c4"/>
 <Box position={[0,.85,.93]} size={[.45,.09,.65]} color={color}/>
 {[-.5,.5].map(x=><group key={x}><Box position={[x,1.65,.72]} size={[.025,.35,.025]} color="#758894"/><Box position={[x,1.84,.72]} size={[.22,.14,.05]} color="#b2cbd5"/></group>)}
 </group>}
function Vehicle({session,slot,data,selected,onSelect}:{session:Session;slot:Slot;data:Data;selected:boolean;onSelect:()=>void}) {
 const ref=useRef<THREE.Group>(null),invalidate=useThree(s=>s.invalidate);
 const x=slot.x,z=slot.z,rotation=slot.rotation*Math.PI/180,moto=session.type==='Moto';
 const points=useMemo(()=>{if(!session.movement)return [];try{return session.movement.path||routeFor(data,slot.id,session.movement.kind);}catch{return [[x,z],[x,z]];}},[session.movement,slot.id,data.slots,data.layout,x,z]);
 const lengths=useMemo(()=>points.slice(1).map((p,i)=>Math.hypot(p[0]-points[i][0],p[1]-points[i][1])),[points]);
 useFrame(()=>{
  if(!ref.current)return;let px=x,pz=z,angle=rotation;
  if(session.movement&&points.length>1){invalidate();const t=THREE.MathUtils.clamp((Date.now()-session.movement.started)/5500,0,1);let travel=t*lengths.reduce((a,b)=>a+b,0),i=0;while(i<lengths.length-1&&travel>lengths[i]){travel-=lengths[i];i++;}const a=points[i],b=points[i+1],u=lengths[i]?Math.min(1,travel/lengths[i]):1;px=a[0]+(b[0]-a[0])*u;pz=a[1]+(b[1]-a[1])*u;angle=Math.atan2(b[0]-a[0],b[1]-a[1]);if((session.movement.kind==='entry'&&i===lengths.length-1)||(session.movement.kind==='exit'&&i===0))angle=rotation;}
  ref.current.position.set(px,.12,pz);ref.current.rotation.y=angle;
 });
 const suv=session.type==='SUV',h=suv?.9:.7;
 return <group ref={ref} name={moto?'vehicle-motorcycle':'vehicle-car'} position={[x,.12,z]} rotation={[0,rotation,0]} onClick={e=>{e.stopPropagation();onSelect();}} onPointerOver={()=>document.body.style.cursor='pointer'} onPointerOut={()=>document.body.style.cursor='auto'}>
 {moto?<Motorcycle color={session.color}/>:<group name="car-model">
  <RoundedBox args={[2.05,h,3.7]} radius={.23} position={[0,.55,0]} castShadow><meshStandardMaterial color={session.color} metalness={.55} roughness={.25}/></RoundedBox>
  <RoundedBox args={[1.78,.68,suv?2.3:1.9]} radius={.22} position={[0,1.08,-.15]} castShadow><meshStandardMaterial color="#152c40" metalness={.5} roughness={.18}/></RoundedBox>
  <Box position={[0,1.43,-.15]} size={[1.6,.08,1.4]} color={session.color}/>
  {[-1.02,1.02].flatMap(a=>[-1.12,1.12].map(b=><mesh key={`${a}-${b}`} position={[a,.35,b]} rotation={[0,0,Math.PI/2]} castShadow><cylinderGeometry args={[.38,.38,.18,16]}/><meshStandardMaterial color="#0c1019"/><mesh position={[0,.1,0]}><cylinderGeometry args={[.22,.22,.19,12]}/><meshStandardMaterial color="#9ca5ae" metalness={.8} roughness={.2}/></mesh></mesh>))}
  {[-.65,.65].map(a=><group key={a}><Box position={[a,.65,1.86]} size={[.48,.16,.04]} color="#f4efcf"/><Box position={[a,.65,-1.86]} size={[.48,.16,.04]} color="#e85961"/></group>)}
</group>}
 {selected&&<><mesh position={[0,.05,0]} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[moto?1.4:2.05,moto?1.48:2.14,48]}/><meshBasicMaterial color="#70ffc1" transparent opacity={.85}/></mesh><Label position={[0,2.6,0]} className="car-tag">{session.plate}</Label></>}
 </group>
}
function Camera({view,reset,layout}:{view:View;reset:number;layout:Layout}) {
 const controls=useRef<OrbitControlsType>(null),{camera,invalidate}=useThree();const moving=useRef(true);
 const target=useRef(new THREE.Vector3(0,0,1));const destination=useRef(new THREE.Vector3(36,42,48));
 useEffect(()=>{const scale=Math.max(layout.width/43,layout.depth/39);const g=gate(layout,view==='exit'?'exit':'entry');const close=view==='entry'||view==='exit';const pos={overview:[34*scale,39*scale,44*scale],top:[0,62*scale,.1],entry:[g[0]+16,17,g[1]+19],exit:[g[0]+11,14,g[1]+7]}[view];destination.current.set(...pos as [number,number,number]);target.current.set(close?g[0]-3:0,0,close?g[1]:1);moving.current=true;invalidate();},[view,reset,layout.width,layout.depth,invalidate]);
 useFrame((_,dt)=>{if(!moving.current||!controls.current)return;invalidate();camera.position.lerp(destination.current,Math.min(1,dt*5));controls.current.target.lerp(target.current,Math.min(1,dt*5));controls.current.update();if(camera.position.distanceTo(destination.current)<.05)moving.current=false;});
 return <OrbitControls ref={controls} makeDefault minDistance={12} maxDistance={Math.max(layout.width,layout.depth)*3} maxPolarAngle={Math.PI/2.1} enableDamping onStart={()=>moving.current=false} target={[0,0,1]}/>;
}
function Gate({open,position}:{open:boolean;position:[number,number,number]}) {const arm=useRef<THREE.Group>(null);const invalidate=useThree(s=>s.invalidate);useFrame((_,dt)=>{if(arm.current){const target=open?Math.PI/2:0;arm.current.rotation.z=THREE.MathUtils.lerp(arm.current.rotation.z,target,Math.min(1,dt*4));if(Math.abs(arm.current.rotation.z-target)>.002)invalidate();}});return <group position={position}><Box position={[0,.9,0]} size={[.65,1.8,.7]} color="#e8eae6"/><group ref={arm} position={[0,1.6,0]}><Box position={[1.9,0,0]} size={[3.8,.16,.2]} color="#f7f5e7"/>{[.5,1.3,2.1,2.9].map(x=><Box key={x} position={[x,0,.11]} size={[.35,.17,.025]} color="#e65d62"/>)}</group></group>}
function World({data,selected,onSelect,view,reset,quality}:{data:Data;selected:string|null;onSelect:(id:string)=>void;view:View;reset:number;quality:boolean}) {
 const [hover,setHover]=useState<string|null>(null);const {layout}=data;const size=Math.max(layout.width,layout.depth);
 const asphalt=useMemo(()=>{const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d')!,img=ctx.createImageData(128,128);for(let i=0;i<img.data.length;i+=4){const c=56+Math.random()*12;img.data[i]=c;img.data[i+1]=c+5;img.data[i+2]=c+11;img.data[i+3]=255;}ctx.putImageData(img,0,0);const tex=new THREE.CanvasTexture(canvas);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(12,12);return tex;},[]);
 useEffect(()=>()=>asphalt.dispose(),[asphalt]);
 return <><color attach="background" args={['#131e2a']}/><fog attach="fog" args={['#131e2a',size*2,size*4]}/><ambientLight intensity={1.3}/><hemisphereLight args={['#d4e9ff','#688573',1.7]}/><directionalLight position={[-18,35,20]} intensity={2.8} castShadow={quality} shadow-mapSize={quality?[2048,2048]:[512,512]} shadow-camera-left={-size} shadow-camera-right={size} shadow-camera-top={size} shadow-camera-bottom={-size} shadow-bias={-.001}/>
 <Camera view={view} reset={reset} layout={layout}/>
 <Box position={[0,-.55,1]} size={[layout.width,.9,layout.depth]} color="#71817b"/>
 <mesh position={[0,-.045,1]} rotation={[-Math.PI/2,0,0]} receiveShadow><planeGeometry args={[layout.width-.6,layout.depth-.6]}/><meshStandardMaterial map={asphalt} roughness={.96}/></mesh>
 {[-layout.width/2,layout.width/2].map(x=><Box key={x} position={[x,.15,1]} size={[.25,.4,layout.depth]} color="#bac4ba"/>)}
 <Box position={[0,.3,1-layout.depth/2]} size={[layout.width,.7,.4]} color="#a3b0a5"/>
 {data.slots.map(slot=>{const {x,z}=slot,[width,length]=dimensions(slot),s=occupant(data,slot.id),color=statusColor[s?'occupied':slot.status];return <group key={slot.id} position={[x,0,z]} rotation={[0,slot.rotation*Math.PI/180,0]}>
  <mesh rotation={[-Math.PI/2,0,0]} position={[0,.012,0]} onClick={e=>{e.stopPropagation();onSelect(slot.id);}} onPointerOver={e=>{e.stopPropagation();setHover(slot.id);document.body.style.cursor='pointer';}} onPointerOut={()=>{setHover(null);document.body.style.cursor='auto';}}><planeGeometry args={[width-.1,length-.1]}/><meshStandardMaterial color={color} transparent opacity={selected===slot.id?.24:.09} depthWrite={false}/></mesh>
  {[-width/2,width/2].map(xx=><Box key={xx} position={[xx,.025,0]} size={[.055,.03,length]} color="#c1c8bf"/>)}
  <Box position={[0,.03,-length/2]} size={[width,.035,.055]} color="#c1c8bf"/><Box position={[0,.04,length/2-.1]} size={[width-.8,.04,.15]} color={color}/>
  <Label position={[0,.15,length/2-.65]} className="slot-label">{slot.id}</Label>
  {hover===slot.id&&<Label position={[0,2.8,0]} className="car-tag">{`${slot.id} · ${s?'Ocupada':slot.status==='available'?'Disponível':slot.status==='reserved'?'Reservada':'Bloqueada'}`}</Label>}
 </group>})}
 {presentVehicles(data).map(s=>{const slot=data.slots.find(v=>v.id===s.slot);return slot?<Vehicle key={s.id} session={s} slot={slot} data={data} selected={selected===s.slot} onSelect={()=>onSelect(s.slot)}/>:null;})}
 {Array.from(new Set(data.slots.map(s=>s.sector))).map(sector=>{const slots=data.slots.filter(s=>s.sector===sector),x=Math.min(...slots.map(s=>s.x))-2.4,z=slots.reduce((a,s)=>a+s.z,0)/slots.length;return <Label key={sector} position={[x,.8,z]} className="sector-label">{sector}</Label>;})}
 {layout.items.map(item=><group key={item.id} position={[item.x,0,item.z]} rotation={[0,item.rotation*Math.PI/180,0]}>
 {item.kind==='booth'?<><RoundedBox args={[item.width-.8,3,item.depth-.8]} radius={.12} position={[0,1.5,0]} castShadow><meshStandardMaterial color="#cad1c7"/></RoundedBox><Box position={[0,2,(item.depth-.8)/2+.03]} size={[Math.max(.3,item.width-1.7),1.4,.08]} color="#214253"/><Box position={[0,3.1,0]} size={[item.width,.25,item.depth]} color="#1a2a35"/><Label position={[0,3.7,0]} className="building-label">ALLUS PARK</Label></>:item.kind==='tree'?<><Box position={[0,.18,0]} size={[item.width,.4,item.depth]} color="#a5b1a3"/><Box position={[0,.42,0]} size={[item.width-.2,.1,item.depth-.2]} color="#4c7352"/><mesh position={[0,1.5,0]} castShadow><cylinderGeometry args={[.13,.19,2.5,8]}/><meshStandardMaterial color="#665a45"/></mesh><mesh position={[0,3,0]} scale={[Math.max(.4,item.width/2.4),1,Math.max(.4,item.depth/4)]} castShadow><icosahedronGeometry args={[1.65,2]}/><meshStandardMaterial color="#517b5e" roughness={1}/></mesh></>:<Box position={[0,.9,0]} size={[item.width,1.8,item.depth]} color="#879992"/>}
 </group>)}
 {(['entry','exit'] as const).map(kind=>{const [x,z]=gate(layout,kind);return <Gate key={kind} open={data.sessions.some(s=>s.movement?.kind===kind)} position={[x-1.7,0,z]}/>;})}
 {Array.from({length:6},(_,i)=><Box key={i} position={[layout.width/2-12+i*.65,.025,layout.depth/2-2.5]} size={[.36,.03,3]} color="#dedfd2"/>)}
 {[-layout.width/2+.5,layout.width/2-.5].flatMap(x=>[3-layout.depth/2,layout.depth/2-7].map(z=><group key={`${x}${z}`} position={[x,0,z]}><Box position={[0,2.8,0]} size={[.12,5.6,.12]} color="#899b9a"/><Box position={[.5,5.5,0]} size={[1.2,.12,.45]} color="#dce6cf"/></group>))}
 {quality&&<ContactShadows position={[0,-.03,0]} opacity={.28} scale={size*1.6} blur={2} far={12} resolution={256}/>}
 </>
}
const presentVehicles=(d:Data)=>d.sessions.filter(s=>!s.exit||s.movement?.kind==='exit');
class SceneBoundary extends Component<{children:ReactNode;fallback:ReactNode},{error:boolean}>{state={error:false};static getDerivedStateFromError(){return {error:true};}render(){return this.state.error?this.props.fallback:this.props.children;}}
export default function ParkingScene(props:{data:Data;selected:string|null;onSelect:(id:string)=>void;view:View;reset:number;quality:boolean}) {
 const [supported]=useState(()=>{try {const c=document.createElement('canvas');return !!(c.getContext('webgl2')||c.getContext('webgl'));}catch{return false;}});
 const fallback=<div className="fallback"><p>Visualização 2D · WebGL indisponível neste dispositivo</p><div className="slot-grid">{props.data.slots.map(slot=><button key={slot.id} className={occupant(props.data,slot.id)?'occupied':slot.status} onClick={()=>props.onSelect(slot.id)}>{slot.id}<small>{occupant(props.data,slot.id)?.plate||'Livre'}</small></button>)}</div></div>;
 if(!supported)return fallback;
 return <SceneBoundary fallback={fallback}><Suspense fallback={<div className="scene-loading">Preparando seu estacionamento…</div>}><Canvas frameloop="demand" shadows={props.quality} camera={{position:[34,39,44],fov:38,near:.1,far:500}} dpr={props.quality?[1,1.75]:1} gl={{antialias:props.quality,powerPreference:'high-performance'}} onCreated={({gl})=>gl.setClearColor('#131e2a')}><World {...props}/></Canvas></Suspense></SceneBoundary>;
}
