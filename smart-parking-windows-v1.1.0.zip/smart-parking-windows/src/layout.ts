import type { Data, Slot } from './domain';
export type Rotation=0|90|180|270;
export type Point=[number,number];
export interface MapItem { id:string; kind:'tree'|'booth'|'wall'; x:number; z:number; rotation:Rotation; width:number; depth:number }
export interface Layout { width:number; depth:number; items:MapItem[] }
export const defaultLayout=():Layout=>({width:43,depth:39,items:[{id:'booth',kind:'booth',x:3,z:18.1,rotation:0,width:6.8,depth:3.8},...[-12,-2,8].map((z,i)=>({id:`tree-${i}`,kind:'tree' as const,x:-18.4,z,rotation:0 as const,width:2.4,depth:4}))]});
export const legacyGeometry=(id:string)=>({x:(Number(id.slice(1))-1)*3.5-12.25,z:('ABC'.indexOf(id[0])-1)*10,rotation:0 as Rotation,kind:'car' as const,sector:id[0]});
export function dimensions(s:Slot):Point{return s.kind==='motorcycle'?[1.8,3.2]:[3.3,5.6];}
export function extents(item:{width:number;depth:number;rotation:Rotation}):Point{return item.rotation%180===0?[item.width,item.depth]:[item.depth,item.width];}
export function slotExtents(s:Slot):Point {const [width,depth]=dimensions(s);return extents({width,depth,rotation:s.rotation});}
export const snap=(n:number)=>Math.round(n*2)/2;
export const gate=(l:Layout,kind:'entry'|'exit'):Point=>[l.width/2-(kind==='entry'?5.5:2),l.depth/2-2.5];
export function overlaps(a:{x:number;z:number;size:Point},b:{x:number;z:number;size:Point},margin=0){return Math.abs(a.x-b.x)<(a.size[0]+b.size[0])/2+margin-.01&&Math.abs(a.z-b.z)<(a.size[1]+b.size[1])/2+margin-.01;}
function validateGeometry(slots:Slot[],layout:Layout){
 if(!layout||!Number.isFinite(layout.width)||!Number.isFinite(layout.depth)||layout.width<32||layout.width>80||layout.depth<32||layout.depth>80||!Array.isArray(layout.items)||layout.items.length>100)throw Error('O pátio deve medir de 32 a 80 metros por lado e ter até 100 elementos.');
 if(!slots.length||slots.length>120)throw Error('O mapa deve ter entre 1 e 120 vagas.');
 if(new Set(slots.map(s=>s.id)).size!==slots.length||new Set(layout.items.map(i=>i.id)).size!==layout.items.length)throw Error('Há códigos duplicados no mapa.');
 const objects=[...slots.map(s=>{if(!/^[A-Z0-9-]{1,12}$/.test(s.id)||typeof s.sector!=='string'||!s.sector.trim()||s.sector.length>12||!['car','motorcycle'].includes(s.kind))throw Error('Código, setor ou tipo de vaga inválido.');return {...s,size:slotExtents(s),label:`Vaga ${s.id}`};}),...layout.items.map(i=>{if(typeof i.id!=='string'||!i.id||i.id.length>64||!['tree','booth','wall'].includes(i.kind)||!Number.isFinite(i.width)||!Number.isFinite(i.depth)||i.width<.3||i.depth<.3||i.width>12||i.depth>12)throw Error('Elemento do mapa inválido.');if(i.kind==='booth'&&(i.width<2||i.depth<2)||i.kind==='tree'&&(i.width<1||i.depth<1))throw Error('Guaritas precisam ter pelo menos 2 × 2 m; árvores, 1 × 1 m.');return {...i,size:extents(i),label:i.kind==='tree'?'Árvore':i.kind==='booth'?'Guarita':'Muro'};})];
 for(const o of objects){
  if(!Number.isFinite(o.x)||!Number.isFinite(o.z)||![0,90,180,270].includes(o.rotation))throw Error('Posição ou rotação inválida.');
  if(Math.abs(o.x)+o.size[0]/2>layout.width/2-.35||Math.abs(o.z-1)+o.size[1]/2>layout.depth/2-.35)throw Error(`${o.label} está fora dos limites do pátio.`);
 }
 for(let i=0;i<objects.length;i++)for(let j=i+1;j<objects.length;j++)if(overlaps(objects[i],objects[j],.05))throw Error(`${objects[i].label} está sobreposta a ${objects[j].label}.`);
 for(const kind of ['entry','exit'] as const){const [x,z]=gate(layout,kind);if(objects.some(o=>overlaps(o,{x,z:z+1,size:[3.5,5]})))throw Error('Mantenha livres os corredores junto às cancelas de entrada e saída.');}
}
// Navigation uses a half-meter grid, excluding bays and scenery with vehicle clearance.
// One flood fill serves all bays; routes end in a short, straight parking maneuver.
export function navigation(slots:Slot[],layout:Layout,kind:'entry'|'exit') {
 const step=.5,minX=-layout.width/2,minZ=1-layout.depth/2,nx=Math.floor(layout.width/step)+1,nz=Math.floor(layout.depth/step)+1,total=nx*nz;
 const blocked=new Uint8Array(total),parent=new Int32Array(total).fill(-1);
 const index=(p:Point)=>Math.round((p[1]-minZ)/step)*nx+Math.round((p[0]-minX)/step);
 const point=(i:number):Point=>[minX+(i%nx)*step,minZ+Math.floor(i/nx)*step];
 const rects=[...slots.map(s=>({x:s.x,z:s.z,size:slotExtents(s)})),...layout.items.map(i=>({x:i.x,z:i.z,size:extents(i)}))];
 const pad=1.05;
 for(let z=0;z<nz;z++)for(let x=0;x<nx;x++)if(x*step<1.05||z*step<1.05||x*step>layout.width-1.05||z*step>layout.depth-1.05)blocked[z*nx+x]=1;
 for(const r of rects){
  const x0=Math.max(0,Math.ceil((r.x-r.size[0]/2-pad-minX)/step)),x1=Math.min(nx-1,Math.floor((r.x+r.size[0]/2+pad-minX)/step));
  const z0=Math.max(0,Math.ceil((r.z-r.size[1]/2-pad-minZ)/step)),z1=Math.min(nz-1,Math.floor((r.z+r.size[1]/2+pad-minZ)/step));
  for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++)blocked[z*nx+x]=1;
 }
 const start=index(gate(layout,kind));
 const queue=new Int32Array(total);let head=0,tail=0;
 if(start>=0&&start<total&&!blocked[start]){parent[start]=start;queue[tail++]=start;}
 while(head<tail){const i=queue[head++],x=i%nx,z=Math.floor(i/nx);const next=[...(x>0?[i-1]:[]),...(x<nx-1?[i+1]:[]),...(z>0?[i-nx]:[]),...(z<nz-1?[i+nx]:[])];for(const n of next)if(!blocked[n]&&parent[n]===-1){parent[n]=i;queue[tail++]=n;}}
 return (slot:Slot):Point[]=>{
  const angle=slot.rotation*Math.PI/180,distance=dimensions(slot)[1]/2+1.4;
  const approach:Point=[slot.x+Math.sin(angle)*distance,slot.z+Math.cos(angle)*distance];
  const goal=index(approach);if(approach[0]<minX+1.05||approach[0]>layout.width/2-1.05||approach[1]<minZ+1.05||approach[1]>1+layout.depth/2-1.05||goal<0||goal>=total||parent[goal]===-1)throw Error(`Vaga ${slot.id} sem acesso à ${kind==='entry'?'entrada':'saída'}. Deixe um corredor de circulação com pelo menos 3 metros.`);
  const raw:Point[]=[];let cursor=goal;
  while(cursor!==start){raw.push(point(cursor));cursor=parent[cursor];}raw.push(point(start));raw.reverse();
  const compact:Point[]=[];
  for(let i=0;i<raw.length;i++){const a=raw[i-1],b=raw[i],c=raw[i+1];if(!a||!c||(b[0]-a[0])*(c[1]-b[1])!==(b[1]-a[1])*(c[0]-b[0]))compact.push(b);}
  const outside:Point=[gate(layout,kind)[0],1+layout.depth/2+2];
  const route=[outside,...compact,approach,[slot.x,slot.z] as Point];
  return kind==='exit'?route.reverse():route;
 };
}
export function routeFor(data:Pick<Data,'slots'|'layout'>,id:string,kind:'entry'|'exit'):Point[]{const slot=data.slots.find(s=>s.id===id);if(!slot)throw Error('Vaga não encontrada no mapa.');return navigation(data.slots,data.layout,kind)(slot);}
export function validateMap(slots:Slot[],layout:Layout,checkAccess=true){validateGeometry(slots,layout);if(checkAccess)for(const kind of ['entry','exit'] as const){const route=navigation(slots,layout,kind);for(const s of slots)route(s);}}
export function saveMap(d:Data,slots:Slot[],layout:Layout):Data{
 if(d.sessions.some(s=>s.movement))throw Error('Aguarde o fim da manobra antes de salvar o mapa.');
 for(const old of d.slots){
  const next=slots.find(s=>s.id===old.id),live=d.sessions.some(s=>s.slot===old.id&&(!s.exit||s.movement));
  if(!next&&(live||old.status==='reserved'||d.members.some(m=>m.fixedSlot===old.id)))throw Error(`A vaga ${old.id} está ocupada, reservada ou vinculada a um mensalista e não pode ser removida.`);
  if(next&&live&&(next.x!==old.x||next.z!==old.z||next.rotation!==old.rotation||next.kind!==old.kind))throw Error(`Libere a vaga ${old.id} antes de mover, girar ou alterar seu tipo.`);
 }
 validateMap(slots,layout);
 return {...d,slots:slots.map(s=>{const old=d.slots.find(v=>v.id===s.id);return {...s,status:old?.status||'available',reservedFor:old?.reservedFor};}),layout:structuredClone(layout)};
}
