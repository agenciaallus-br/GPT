import { defaultLayout, legacyGeometry, validateMap } from './layout';
import { create } from 'zustand';
import { demo, validPlate, validateRates, saveMember, present, type Data } from './domain';
export const STORAGE_KEY='allus-parking-v1';
function object(v:unknown):v is Record<string,unknown>{return !!v&&typeof v==='object'&&!Array.isArray(v)}
export function parseBackup(raw:string):Data {
 let d:unknown=JSON.parse(raw);
 if(!object(d)||![1,2].includes(d.version as number)) throw Error('Versão de backup inválida.');
 if(d.version===1){
  if(!Array.isArray(d.slots)||d.slots.some(s=>!object(s)||typeof s.id!=='string'||! /^[ABC]0[1-8]$/.test(s.id)))throw Error('Vagas do backup antigo inválidas.');
  d={...d,version:2,layout:defaultLayout(),slots:d.slots.map(s=>({...s,...legacyGeometry(s.id)}))};
 }
 if(!object(d))throw Error('Backup inválido.');
 const fields=['slots','sessions','members','transactions'] as const;
 for(const field of fields) if(!Array.isArray(d[field])||(d[field] as unknown[]).length>100000) throw Error('Estrutura de backup inválida.');
 const data=d as unknown as Data;
 const template=demo();
 for(const field of fields){
  const sample=template[field][0] as unknown as Record<string,unknown>;
  for(const row of data[field]) {
   if(!object(row)) throw Error('Registro inválido.');
   for(const key of Object.keys(sample)) {
    if(['exit','amount','method','memberId'].includes(key)) continue;
    if(typeof row[key]!==typeof sample[key]) throw Error(`Campo inválido: ${field}.${key}`);
    if(typeof row[key]==='string'&&(row[key] as string).length>512) throw Error('Campo de texto excessivamente longo.');
    if(typeof row[key]==='number'&&!Number.isFinite(row[key])) throw Error('Número inválido.');
   }
  }
  if(new Set(data[field].map(r=>r.id)).size!==data[field].length) throw Error('Identificadores duplicados.');
 }
 if(data.slots.some(s=>!['available','reserved','blocked'].includes(s.status))) throw Error('Status de vaga inválido.');
 validateMap(data.slots,data.layout);
 if(data.slots.some(s=>s.status==='reserved'&&!validPlate(s.reservedFor||''))) throw Error('Reserva sem placa válida.');
 if(!object(data.rates)) throw Error('Tarifas ausentes.'); validateRates(data.rates);
 for(const s of data.sessions){
  validateRates(s.rate);
  if(((!s.exit||s.movement?.kind==='exit')&&!data.slots.some(slot=>slot.id===s.slot))||!['Avulso','Mensalista'].includes(s.category)||!/^([A-Z]{3}[0-9][A-Z0-9][0-9]{2})$/.test(s.plate)||!Number.isFinite(s.entry)) throw Error('Veículo ou vaga inválido.');
  if(s.exit!==undefined&&(!Number.isFinite(s.exit)||s.exit<s.entry||!Number.isFinite(s.amount)||!['Pix','Crédito','Débito','Dinheiro','Cortesia'].includes(s.method!))) throw Error('Saída inválida.');
  if(s.movement?.path&&(!Array.isArray(s.movement.path)||s.movement.path.length<2||s.movement.path.length>1000||s.movement.path.some(p=>!Array.isArray(p)||p.length!==2||p.some(n=>!Number.isFinite(n)||Math.abs(n)>100))))throw Error('Trajeto de veículo inválido.');
  if(s.movement&&(!object(s.movement)||!['entry','exit'].includes(s.movement.kind)||!Number.isFinite(s.movement.started)||(s.movement.kind==='exit'&&!s.exit))) throw Error('Movimento inválido.');
 }
 for(const t of data.transactions) {
  if(t.sessionId&&!data.sessions.some(s=>s.id===t.sessionId&&s.exit&&s.amount===t.amount&&s.method===t.method)) throw Error('Transação sem saída correspondente.');
  if(t.memberId&&!data.members.some(m=>m.id===t.memberId)) throw Error('Mensalista da transação não encontrado.');
 }
 for(const t of data.transactions) if(!Number.isFinite(t.amount)||t.amount<0||!Number.isFinite(t.at)||!['Avulso','Mensalista'].includes(t.kind)||!['Pix','Crédito','Débito','Dinheiro','Cortesia'].includes(t.method)) throw Error('Transação inválida.');
 for(const m of data.members) saveMember(data,m);
 const live=present(data);
 if(new Set(live.map(s=>s.plate)).size!==live.length||new Set(live.map(s=>s.slot)).size!==live.length) throw Error('Há placas ou vagas ocupadas em duplicidade.');
 for(const s of data.sessions.filter(s=>s.exit)){
  const tx=data.transactions.filter(t=>t.sessionId===s.id);
  if(tx.length!==1||tx[0].amount!==s.amount) throw Error('Pagamento inconsistente com o histórico.');
 }
 return data;
}
let initial:Data,warning='';
try {const raw=localStorage.getItem(STORAGE_KEY); initial=raw?parseBackup(raw):demo();if(!raw)warning=persist(initial);} catch {initial=demo(); warning='Não foi possível carregar os dados locais. Exporte um backup antes de continuar. Os dados antigos não foram sobrescritos.';}
interface Store { data:Data; notice:string; storageError:string; update:(fn:(d:Data)=>Data)=>boolean; replace:(d:Data)=>void; notify:(s:string)=>void }
function persist(d:Data):string {try{localStorage.setItem(STORAGE_KEY,JSON.stringify(d));return '';}catch{return 'Não foi possível salvar no navegador. Exporte um backup para não perder alterações.';}}
export const useParking=create<Store>((set,get)=>({data:initial,notice:'',storageError:warning,notify:notice=>set({notice}),update:fn=>{try {const data=fn(get().data); if(data!==get().data)set({data,storageError:persist(data)});return true;}catch(e){set({notice:(e as Error).message});return false;}},replace:data=>set({data,storageError:persist(data)})}));
export function download(content:string,name:string,type='application/json') {const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export function exportCSV(rows:Record<string,unknown>[],name:string){const keys=Object.keys(rows[0]||{});const cell=(v:unknown)=>`"${String(v??'').replace(/^[=+@-]/,"'$&").replaceAll('"','""')}"`;download('\uFEFF'+[keys.map(cell).join(';'),...rows.map(r=>keys.map(k=>cell(r[k])).join(';'))].join('\r\n'),name,'text/csv;charset=utf-8');}
