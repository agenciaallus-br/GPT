# Allus Park — Smart Parking 3D

Aplicação demonstrativa de gerenciamento de estacionamento em React, TypeScript, Vite, React Three Fiber/Three.js, Drei, Zustand, Recharts e Lucide. Interface em português, fonte Inter instalada localmente e estilos responsivos em CSS.

## Executar

Requer Node.js 24 e npm 11 (ambiente validado).

```bash
cd /workspace/GPT
npm ci
npm run dev -- --port 5173
```

Para produção: `npm run build`, depois `npm run preview -- --port 4173`. A aplicação é estática; não requer chaves, banco de dados ou serviços externos. Sirva `dist/` com um servidor HTTP. Não abra `index.html` por `file://`.

## Funcionalidades

- Pátio 3D com 24 vagas, três setores, veículos selecionáveis, guarita, cancelas, jardins, sinalização, iluminação e textura de asfalto gerada localmente.
- Orbitar, mover, aproximar e alternar câmeras. Modo gráfico leve, renderização sob demanda e alternativa 2D se WebGL não estiver disponível.
- Dados demonstrativos coerentes: 14 veículos presentes, 10 vagas livres, três mensalistas, histórico e recebimentos.
- Entrada com placa validada, sugestão de vaga e animação por corredor de circulação. Clique em uma vaga antes de registrar para definir o destino.
- Consulta e edição de veículo, transferência imediata entre vagas e reserva por placa ou bloqueio de vagas livres.
- Saída com tarifa calculada, cinco métodos de pagamento simulados, manobra animada e liberação da vaga. Uma única transação por saída.
- Apenas uma manobra por vez para evitar cruzamentos entre veículos em movimento.
- Dashboard, gráficos interativos, histórico pesquisável, filtros de data e categoria, financeiro por período e exportações CSV.
- Cadastro e edição de mensalistas, planos fixos ou rotativos e recebimento simulado. Renovar o vencimento pela edição inicia uma nova mensalidade a receber. Um plano válido exige situação ativa, pagamento recebido e vencimento vigente.
- Tarifas configuráveis, faixa de desconto, teto a cada 24 horas e horas adicionais iniciadas ou proporcionais. Os primeiros minutos são gratuitos até a tolerância; ultrapassada, a primeira hora é integral. Tarifas são congeladas na entrada. Mensalistas válidos não geram cobrança avulsa.
- Persistência local automática, backup JSON com validação antes da importação, confirmação antes de substituição/limpeza e recuperação de manobras após atualizar a página.

## Validação

```bash
npm test
npm run build
npm run test:e2e
```

Os testes de domínio exercitam tarifas, invariantes operacionais, mensalistas e backups. Os testes de navegador exercitam o ciclo de entrada e saída, persistência, navegação administrativa, exportação, WebGL e layout móvel. O Playwright usa `/usr/bin/chromium` quando disponível. Em outra máquina, execute `npx playwright install chromium` ou defina `CHROMIUM_PATH` com o caminho do navegador. A configuração inicia o Vite se necessário.

## Estrutura

- `src/domain.ts`: entidades e operações puras, cálculo de tarifa e dados de demonstração.
- `src/store.ts`: estado Zustand, persistência e importação/exportação. Fronteira a substituir por um repositório remoto numa futura integração com Supabase.
- `src/components/ParkingScene.tsx`: cena procedural, seleção, câmeras, trajetos e cancelas.
- `src/components/Forms.tsx`: entradas, saídas, transferências e mensalistas.
- `src/components/Admin.tsx`: indicadores, gráficos, financeiro, histórico e configurações.
- `src/App.tsx`: navegação, painel contextual e integração entre operação e cena.

## Limites desta versão

Os veículos são modelos procedurais estilizados; não foram fornecidas imagens ou modelos 3D de referência. Transferências entre vagas são imediatas; entradas e saídas possuem animação. Não há cobrança real, autenticação, backend, sincronização entre dispositivos/operadores ou bloqueio concorrente entre abas. O armazenamento é exclusivo do navegador e da origem HTTP: use backups. A versão demonstrativa não é infraestrutura definitiva de uma operação comercial. Use uma única aba operacional.

Os relatórios são derivados dos registros locais; os dados iniciais são explicitamente demonstrativos. Os horários usam o fuso do navegador. Os gráficos de ocupação usam as entradas e saídas históricas, sem projetar horas futuras.
