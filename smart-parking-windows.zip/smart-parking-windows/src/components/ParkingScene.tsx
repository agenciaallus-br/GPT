import { Suspense, useMemo, useRef, useState, useEffect, Component, type ReactNode } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, ContactShadows, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import type { OrbitControls as OrbitControlsType } from 'three-stdlib';
import { occupant, type Data, type Session } from '../domain';
export type View='overview'|'top'|'entry'|'exit';
const statusColor={available:'#30e6a0',occupied:'#fb6478',reserved:'#f6c76a',blocked:'#738096'};
export const coordinates=(id:string):[number,number]=>[(Number(id.slice(1))-1)*3.5-12.25,('ABC'.indexOf(id[0])-1)*10];
function Box({position,size,color,...props}:{position:[number,number,number];size:[number,number,number];color:string;[key:string]:unknown}){return <mesh position={position} castShadow receiveShadow {...props}><boxGeometry args={size}/><meshStandardMaterial color={color} roughness={.75}/></mesh>}
function Label({position,children,className='scene-label'}:{position:[number,number,number];children:string;className?:string}) {
 const {texture,ratio}=useMemo(()=>{
  const c=document.createElement('canvas'),ctx=c.getContext('2d')!;
  ctx.font='600 48px Inter, sans-serif';const width=Math.ceil(ctx.measureText(children).width)+36;c.width=width;c.height=80;
  ctx.font='600 48px Inter, sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
  const tag=className==='car-tag'||className==='building-label';if(tag){ctx.fillStyle='#142b35';ctx.fillRect(0,0,width,80);ctx.strokeStyle='#7bbaa3';ctx.lineWidth=3;ctx.strokeRect(1,1,width-2,78);}
  ctx.fillStyle=className==='sector-label'?'#9fbdb0':className==='building-label'?'#9ff3ce':'#d5e2dc';ctx.shadowColor='#0008';ctx.shadowBlur=3;ctx.fillText(children,width/2,42);
  return {texture:new THREE.CanvasTexture(c),ratio:width/80};
 },[children,className]);
 useEffect(()=>()=>texture.dispose(),[texture]);
 const height=className==='sector-label'?1.5:className==='building-label'?1.05:className==='car-tag'?1:.58;
 return <sprite position={position} scale={[height*ratio,height,1]} raycast={()=>{}}><spriteMaterial map={texture} transparent depthWrite={false}/></sprite>;
}
function Car({session,selected,onSelect}:{session:Session;selected:boolean;onSelect:()=>void}) {
 const ref=useRef<THREE.Group>(null);const invalidate=useThree(s=>s.invalidate);
 const [x,z]=coordinates(session.slot);
 useFrame(()=>{
  if(!ref.current)return;
  let px=x,pz=z,angle=0;
  if(session.movement){
   invalidate();
   let t=THREE.MathUtils.clamp((Date.now()-session.movement.started)/5500,0,1);
   if(session.movement.kind==='exit')t=1-t;
   // A dedicated east-side spine joins each circulation lane; final segment backs into the bay.
   const spine=session.movement.kind==='exit'?19.5:16;
   const points=[[spine,20],[spine,z+4],[x,z+4],[x,z]];
   const lens=points.slice(1).map((p,i)=>Math.hypot(p[0]-points[i][0],p[1]-points[i][1]));
   let travel=t*lens.reduce((a,b)=>a+b,0),i=0;
   while(i<2&&travel>lens[i]) {travel-=lens[i];i++;}
   const u=Math.min(1,travel/lens[i]),a=points[i],b=points[i+1];px=a[0]+(b[0]-a[0])*u;pz=a[1]+(b[1]-a[1])*u;
   angle=Math.atan2(b[0]-a[0],b[1]-a[1]); if(session.movement.kind==='exit')angle+=Math.PI; if(i===2)angle=0;
  }
  ref.current.position.set(px,.12,pz);ref.current.rotation.y=angle;
 });
 const suv=session.type==='SUV',h=suv?.9:.7;
 return <group ref={ref} position={[x,.12,z]} onClick={e=>{e.stopPropagation();onSelect();}} onPointerOver={()=>document.body.style.cursor='pointer'} onPointerOut={()=>document.body.style.cursor='auto'}>
  <RoundedBox args={[2.05,h,3.7]} radius={.23} position={[0,.55,0]} castShadow><meshStandardMaterial color={session.color} metalness={.55} roughness={.25}/></RoundedBox>
  <RoundedBox args={[1.78,.68,suv?2.3:1.9]} radius={.22} position={[0,1.08,-.15]} castShadow><meshStandardMaterial color="#152c40" metalness={.5} roughness={.18}/></RoundedBox>
  <Box position={[0,1.43,-.15]} size={[1.6,.08,1.4]} color={session.color}/>
  {[-1.02,1.02].flatMap(a=>[-1.12,1.12].map(b=><mesh key={`${a}-${b}`} position={[a,.35,b]} rotation={[0,0,Math.PI/2]} castShadow><cylinderGeometry args={[.38,.38,.18,16]}/><meshStandardMaterial color="#0c1019"/><mesh position={[0,.1,0]}><cylinderGeometry args={[.22,.22,.19,12]}/><meshStandardMaterial color="#9ca5ae" metalness={.8} roughness={.2}/></mesh></mesh>))}
  {[-.65,.65].map(a=><group key={a}><Box position={[a,.65,1.86]} size={[.48,.16,.04]} color="#f4efcf"/><Box position={[a,.65,-1.86]} size={[.48,.16,.04]} color="#e85961"/></group>)}
  {selected&&<><mesh position={[0,.05,0]} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[2.05,2.14,48]}/><meshBasicMaterial color="#70ffc1" transparent opacity={.85}/></mesh><Label position={[0,2.6,0]} className="car-tag">{session.plate}</Label></>}
 </group>
}
function Camera({view,reset}:{view:View;reset:number}) {
 const controls=useRef<OrbitControlsType>(null),{camera,invalidate}=useThree();const moving=useRef(true);
 const target=useRef(new THREE.Vector3(0,0,1));const destination=useRef(new THREE.Vector3(36,42,48));
 useEffect(()=>{const pos={overview:[34,39,44],top:[0,62,.1],entry:[32,17,36],exit:[30,14,24]}[view];destination.current.set(...pos as [number,number,number]);target.current.set(view==='entry'||view==='exit'?13:0,0,view==='entry'||view==='exit'?16:1);moving.current=true;invalidate();},[view,reset,invalidate]);
 useFrame((_,dt)=>{if(!moving.current||!controls.current)return;invalidate();camera.position.lerp(destination.current,Math.min(1,dt*5));controls.current.target.lerp(target.current,Math.min(1,dt*5));controls.current.update();if(camera.position.distanceTo(destination.current)<.05)moving.current=false;});
 return <OrbitControls ref={controls} makeDefault minDistance={12} maxDistance={90} maxPolarAngle={Math.PI/2.1} enableDamping onStart={()=>moving.current=false} target={[0,0,1]}/>;
}
function Gate({open,position}:{open:boolean;position:[number,number,number]}) {const arm=useRef<THREE.Group>(null);const invalidate=useThree(s=>s.invalidate);useFrame((_,dt)=>{if(arm.current){const target=open?Math.PI/2:0;arm.current.rotation.z=THREE.MathUtils.lerp(arm.current.rotation.z,target,Math.min(1,dt*4));if(Math.abs(arm.current.rotation.z-target)>.002)invalidate();}});return <group position={position}><Box position={[0,.9,0]} size={[.65,1.8,.7]} color="#e8eae6"/><group ref={arm} position={[0,1.6,0]}><Box position={[1.9,0,0]} size={[3.8,.16,.2]} color="#f7f5e7"/>{[.5,1.3,2.1,2.9].map(x=><Box key={x} position={[x,0,.11]} size={[.35,.17,.025]} color="#e65d62"/>)}</group></group>}
function World({data,selected,onSelect,view,reset,quality}:{data:Data;selected:string|null;onSelect:(id:string)=>void;view:View;reset:number;quality:boolean}) {
 const [hover,setHover]=useState<string|null>(null);
 const asphalt=useMemo(()=>{const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d')!,img=ctx.createImageData(128,128);for(let i=0;i<img.data.length;i+=4){const c=56+Math.random()*12;img.data[i]=c;img.data[i+1]=c+5;img.data[i+2]=c+11;img.data[i+3]=255;}ctx.putImageData(img,0,0);const tex=new THREE.CanvasTexture(canvas);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(12,12);return tex;},[]);
 useEffect(()=>()=>asphalt.dispose(),[asphalt]);
 return <><color attach="background" args={['#131e2a']}/><fog attach="fog" args={['#131e2a',80,160]}/><ambientLight intensity={1.3}/><hemisphereLight args={['#d4e9ff','#688573',1.7]}/><directionalLight position={[-18,35,20]} intensity={2.8} castShadow={quality} shadow-mapSize={quality?[2048,2048]:[512,512]} shadow-camera-left={-32} shadow-camera-right={32} shadow-camera-top={30} shadow-camera-bottom={-30} shadow-bias={-.001}/>
 <Camera view={view} reset={reset}/>
 <Box position={[0,-.55,1]} size={[43,.9,39]} color="#71817b"/>
 <mesh position={[0,-.045,1]} rotation={[-Math.PI/2,0,0]} receiveShadow><planeGeometry args={[41,37]}/><meshStandardMaterial map={asphalt} roughness={.96}/></mesh>
 {[-20.5,20.5].map(x=><Box key={x} position={[x,.15,0]} size={[.25,.4,35]} color="#bac4ba"/>)}
 <Box position={[0,.3,-17.4]} size={[41,.7,.4]} color="#a3b0a5"/>
 {data.slots.map(slot=>{const [x,z]=coordinates(slot.id),s=occupant(data,slot.id),color=statusColor[s?'occupied':slot.status];return <group key={slot.id} position={[x,0,z]}>
  <mesh rotation={[-Math.PI/2,0,0]} position={[0,.012,0]} onClick={e=>{e.stopPropagation();onSelect(slot.id);}} onPointerOver={e=>{e.stopPropagation();setHover(slot.id);document.body.style.cursor='pointer';}} onPointerOut={()=>{setHover(null);document.body.style.cursor='auto';}}><planeGeometry args={[3.2,5.5]}/><meshStandardMaterial color={color} transparent opacity={selected===slot.id?.24:.09} depthWrite={false}/></mesh>
  {[-1.65,1.65].map(xx=><Box key={xx} position={[xx,.025,0]} size={[.055,.03,5.6]} color="#c1c8bf"/>)}
  <Box position={[0,.03,-2.75]} size={[3.3,.035,.055]} color="#c1c8bf"/><Box position={[0,.04,2.65]} size={[2.5,.04,.15]} color={color}/>
  <Label position={[0,.08,2.15]} className="slot-label">{slot.id}</Label>
  {hover===slot.id&&<Label position={[0,2.8,0]} className="car-tag">{`${slot.id} · ${s?'Ocupada':slot.status==='available'?'Disponível':slot.status==='reserved'?'Reservada':'Bloqueada'}`}</Label>}
 </group>})}
 {presentVehicles(data).map(s=><Car key={s.id} session={s} selected={selected===s.slot} onSelect={()=>onSelect(s.slot)}/>)}
 {[-10,0,10].map((z,i)=><group key={z}><Label position={[-17,.8,z]} className="sector-label">{['A','B','C'][i]}</Label>{[-9,3].map(x=><group key={x} position={[x,.03,z+4.7]}><Box position={[0,0,0]} size={[2,.03,.09]} color="#b9c2b9"/><Box position={[-.65,0,.27]} size={[.85,.03,.08]} color="#b9c2b9" rotation={[0,.65,0]}/><Box position={[-.65,0,-.27]} size={[.85,.03,.08]} color="#b9c2b9" rotation={[0,-.65,0]}/></group>)}</group>)}
 {/* Entry pavilion and landscaped western edge. */}
 <Box position={[-10,.1,16.5]} size={[20,.22,3]} color="#c4c6b8"/>
 <RoundedBox args={[6,3,3]} radius={.12} position={[3,1.5,16.3]} castShadow><meshStandardMaterial color="#cad1c7"/></RoundedBox>
 <Box position={[3,2,17.83]} size={[4.9,1.4,.08]} color="#214253"/><Box position={[3,3.1,16.3]} size={[6.8,.25,3.8]} color="#1a2a35"/>
 <Label position={[3,3.7,16.3]} className="building-label">ALLUS PARK</Label>
 <Gate open={data.sessions.some(s=>s.movement?.kind==='entry')} position={[14,0,17]}/><Gate open={data.sessions.some(s=>s.movement?.kind==='exit')} position={[19,0,17]}/>
 {Array.from({length:6},(_,i)=><Box key={i} position={[8+i*.65,.025,17]} size={[.36,.03,3]} color="#dedfd2"/>)}
 {[-12,-2,8].map(z=><group key={z} position={[-18.4,0,z]}><Box position={[0,.18,0]} size={[2.4,.4,4]} color="#a5b1a3"/><Box position={[0,.42,0]} size={[2,.1,3.6]} color="#4c7352"/><mesh position={[0,1.5,0]} castShadow><cylinderGeometry args={[.13,.19,2.5,8]}/><meshStandardMaterial color="#665a45"/></mesh><mesh position={[0,3,0]} castShadow><icosahedronGeometry args={[1.65,2]}/><meshStandardMaterial color="#517b5e" roughness={1}/></mesh></group>)}
 {[-15,14].flatMap(x=>[-15,7].map(z=><group key={`${x}${z}`} position={[x,0,z]}><Box position={[0,2.8,0]} size={[.12,5.6,.12]} color="#899b9a"/><Box position={[.5,5.5,0]} size={[1.2,.12,.45]} color="#dce6cf"/></group>))}
 {quality&&<ContactShadows position={[0,-.03,0]} opacity={.28} scale={70} blur={2} far={12} resolution={256}/>}
 </>
}
const presentVehicles=(d:Data)=>d.sessions.filter(s=>!s.exit||s.movement?.kind==='exit');
class SceneBoundary extends Component<{children:ReactNode;fallback:ReactNode},{error:boolean}>{state={error:false};static getDerivedStateFromError(){return {error:true};}render(){return this.state.error?this.props.fallback:this.props.children;}}
export default function ParkingScene(props:{data:Data;selected:string|null;onSelect:(id:string)=>void;view:View;reset:number;quality:boolean}) {
 const [supported]=useState(()=>{try {const c=document.createElement('canvas');return !!(c.getContext('webgl2')||c.getContext('webgl'));}catch{return false;}});
 const fallback=<div className="fallback"><p>Visualização 2D · WebGL indisponível neste dispositivo</p><div className="slot-grid">{props.data.slots.map(slot=><button key={slot.id} className={occupant(props.data,slot.id)?'occupied':slot.status} onClick={()=>props.onSelect(slot.id)}>{slot.id}<small>{occupant(props.data,slot.id)?.plate||'Livre'}</small></button>)}</div></div>;
 if(!supported)return fallback;
 return <SceneBoundary fallback={fallback}><Suspense fallback={<div className="scene-loading">Preparando seu estacionamento…</div>}><Canvas frameloop="demand" shadows={props.quality} camera={{position:[34,39,44],fov:38,near:.1,far:200}} dpr={props.quality?[1,1.75]:1} gl={{antialias:props.quality,powerPreference:'high-performance'}} onCreated={({gl})=>gl.setClearColor('#131e2a')}><World {...props}/></Canvas></Suspense></SceneBoundary>;
}
