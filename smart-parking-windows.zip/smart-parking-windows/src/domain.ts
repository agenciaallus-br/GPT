export type SlotStatus = 'available' | 'reserved' | 'blocked';
export type Payment = 'Pix' | 'Crédito' | 'Débito' | 'Dinheiro' | 'Cortesia';
export type Category = 'Avulso' | 'Mensalista';
export interface Slot { id: string; status: SlotStatus; reservedFor?: string }
export interface Rates { firstHour: number; additionalHour: number; tolerance: number; dailyMax: number; monthly: number; rounding: 'ceil' | 'proportional'; specialStart: number; specialEnd: number; specialDiscount: number }
export interface Session { id: string; plate: string; model: string; type: string; color: string; owner: string; phone: string; category: Category; memberId?: string; slot: string; entry: number; exit?: number; amount?: number; method?: Payment; rate: Rates; movement?: { kind: 'entry' | 'exit'; started: number }; paidMonthly: boolean }
export interface Member { id: string; name: string; phone: string; email: string; document: string; plate: string; model: string; color: string; amount: number; due: string; since: string; fixedSlot: string; paid: boolean; active: boolean }
export interface Transaction { id: string; sessionId?: string; memberId?: string; at: number; amount: number; method: Payment; description: string; kind: 'Avulso' | 'Mensalista' }
export interface Data { version: 1; slots: Slot[]; sessions: Session[]; members: Member[]; transactions: Transaction[]; rates: Rates }
export const defaultRates: Rates = { firstHour: 10, additionalHour: 5, tolerance: 10, dailyMax: 60, monthly: 350, rounding: 'ceil', specialStart: 22, specialEnd: 6, specialDiscount: 0 };
export const money = (n: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(n);
export const time = (n: number) => new Date(n).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
export const day = (n: number) => new Date(n).toLocaleDateString('pt-BR');
export const dateKey = (n: number) => { const d = new Date(n); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
export const duration = (entry: number, end = Date.now()) => { const m = Math.max(0, Math.floor((end-entry)/60000)); return `${String(Math.floor(m/60)).padStart(2,'0')}h ${String(m%60).padStart(2,'0')}min`; };
export const normalizePlate = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, '');
export const validPlate = (s: string) => /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(normalizePlate(s));
export const present = (d: Data) => d.sessions.filter(s => !s.exit || s.movement?.kind === 'exit');
export const occupant = (d: Data, id: string) => present(d).find(s => s.slot === id);
export const memberValid = (m: Member | undefined, now=Date.now()) => !!m && m.active && m.paid && m.due >= dateKey(now);
export function price(s: Session, now=Date.now()): number {
 if (s.paidMonthly) return 0;
 const minutes = Math.max(0, (now-s.entry)/60000), r=s.rate;
 if(minutes<=r.tolerance) return 0;
 const days=Math.floor(minutes/1440), remaining=minutes%1440;
 const hours = r.rounding==='ceil' ? Math.ceil(Math.max(0,remaining-60)/60) : Math.max(0,remaining-60)/60;
 let value=days*r.dailyMax+(remaining>0?Math.min(r.dailyMax,r.firstHour+hours*r.additionalHour):0);
 const h=new Date(s.entry).getHours();
 const special=r.specialStart===r.specialEnd || (r.specialStart<r.specialEnd ? h>=r.specialStart && h<r.specialEnd : h>=r.specialStart || h<r.specialEnd);
 if(special) value*=1-r.specialDiscount/100;
 return Math.round(value*100)/100;
}
export function demo(now=Date.now()): Data {
 const slots: Slot[]= ['A','B','C'].flatMap(s=>Array.from({length:8},(_,i)=>({id:`${s}${String(i+1).padStart(2,'0')}`,status:'available' as const})));
 const models=['Toyota Corolla','Jeep Compass','Volkswagen Polo','Honda Civic','Hyundai HB20','Fiat Pulse','Chevrolet Onix'];
 const colors=['#d1d5db','#3c4757','#407ca0','#e9ecef','#b65c51','#233650','#c0b6a5'];
 const due=new Date(now); due.setDate(due.getDate()+20);
 const members: Member[]=Array.from({length:3},(_,i)=>({id:`member-${i}`,name:['Mariana Costa','Rafael Oliveira','Ana Martins'][i],phone:'11999990000',email:`cliente${i+1}@example.com`,document:'',plate:`ALU${i+1}A0${i}`,model:models[i],color:colors[i],amount:350,due:dateKey(due.getTime()),since:dateKey(now-86400000*30),fixedSlot:slots[i].id,paid:true,active:true}));
 const sessions: Session[]=Array.from({length:14},(_,i)=>({id:`demo-${i}`,plate:i<3?members[i].plate:`PRK${i%10}B${String(i).padStart(2,'0')}`,model:models[i%7],type:i%3===0?'SUV':'Sedã',color:colors[i%7],owner:i<3?members[i].name:'Visitante',phone:'',category:i<3?'Mensalista':'Avulso',memberId:i<3?members[i].id:undefined,slot:slots[i].id,entry:now-(25+i*11)*60000,rate:{...defaultRates},paidMonthly:i<3}));
 const transactions: Transaction[]=members.map(m=>({id:`tx-${m.id}`,memberId:m.id,at:now-86400000*2,amount:m.amount,method:'Pix',description:`Mensalidade · ${m.name}`,kind:'Mensalista'}));
 for(let i=0;i<9;i++) {const exit=now-(i*90+15)*60000,entry=exit-(70+i*10)*60000; const s:Session={id:`past-${i}`,plate:`HIS${i}C0${i}`,model:models[i%7],type:'Sedã',color:colors[i%7],owner:'Visitante',phone:'',category:'Avulso',slot:slots[14+i].id,entry,exit,rate:{...defaultRates},paidMonthly:false,method:i%2?'Crédito':'Pix'}; s.amount=price(s,exit); sessions.push(s); transactions.push({id:`tx-${s.id}`,sessionId:s.id,at:exit,amount:s.amount,method:s.method!,description:`Estacionamento · ${s.plate}`,kind:'Avulso'}); }
 return {version:1,slots,sessions,members,transactions,rates:{...defaultRates}};
}
export type Entry = Pick<Session,'plate'|'model'|'type'|'color'|'owner'|'phone'|'category'|'slot'|'entry'>;
export function enter(d: Data, input: Entry, now=Date.now()): Data {
 const plate=normalizePlate(input.plate), slot=d.slots.find(s=>s.id===input.slot);
 if(!validPlate(plate)) throw Error('Informe uma placa brasileira válida.');
 if(!input.model.trim()) throw Error('Informe o modelo do veículo.');
 if(!Number.isFinite(input.entry)||input.entry>now||input.entry<now-30*86400000) throw Error('Entrada deve estar nos últimos 30 dias e não pode estar no futuro.');
 if(present(d).some(s=>s.plate===plate)) throw Error('Este veículo já está no estacionamento.');
 if(d.sessions.some(s=>s.movement)) throw Error('Aguarde a manobra em andamento antes de registrar outro movimento.');
 const member=d.members.find(m=>normalizePlate(m.plate)===plate);
 if(input.category==='Mensalista' && !memberValid(member,now)) throw Error('Mensalista sem plano válido. Regularize o cadastro ou registre como avulso.');
 if(!slot || occupant(d,slot.id) || slot.status==='blocked' || (slot.status==='reserved' && normalizePlate(slot.reservedFor||'')!==plate)) throw Error('A vaga não está disponível para este veículo.');
 const assigned=d.members.find(m=>m.active&&m.fixedSlot===slot.id);
 if(assigned&&assigned.plate!==plate) throw Error('Vaga fixa vinculada a outro mensalista.');
 if(input.category==='Mensalista' && member?.fixedSlot && member.fixedSlot!==slot.id) throw Error(`O plano possui vaga fixa: ${member.fixedSlot}.`);
 const s:Session={...input,plate,id:crypto.randomUUID(),rate:{...d.rates},paidMonthly:input.category==='Mensalista',memberId:input.category==='Mensalista'?member?.id:undefined,movement:{kind:'entry',started:now}};
 return {...d,slots:d.slots.map(v=>v.id===slot.id&&v.status==='reserved'?{...v,status:'available',reservedFor:undefined}:v),sessions:[...d.sessions,s]};
}
export function checkout(d: Data, id: string, method: Payment, now=Date.now()): Data {
 const s=d.sessions.find(s=>s.id===id);
 if(!s||s.exit||s.movement) throw Error('Saída já registrada ou veículo em movimento.');
 if(d.sessions.some(v=>v.movement)) throw Error('Aguarde a manobra em andamento.');
 if(!['Pix','Crédito','Débito','Dinheiro','Cortesia'].includes(method)) throw Error('Forma de pagamento inválida.');
 const amount=method==='Cortesia'?0:price(s,now);
 return {...d,sessions:d.sessions.map(v=>v.id===id?{...v,exit:now,amount,method,movement:{kind:'exit',started:now}}:v),transactions:[...d.transactions,{id:crypto.randomUUID(),sessionId:id,at:now,amount,method,description:`Estacionamento · ${s.plate}`,kind:s.paidMonthly?'Mensalista':'Avulso'}]};
}
export function finishMovements(d: Data, now=Date.now()): Data {
 if(!d.sessions.some(s=>s.movement&&now-s.movement.started>=5500)) return d;
 return {...d,sessions:d.sessions.map(s=>s.movement&&now-s.movement.started>=5500?{...s,movement:undefined}:s)};
}
export function move(d:Data,id:string,to:string):Data {
 const s=d.sessions.find(s=>s.id===id),target=d.slots.find(s=>s.id===to);
 if(!s||s.exit||s.movement||!target||target.status!=='available'||occupant(d,to)) throw Error('Transferência indisponível. Escolha uma vaga livre.');
 const member=d.members.find(m=>m.id===s.memberId);
 if(member?.fixedSlot&&member.fixedSlot!==to) throw Error('Altere a vaga fixa no cadastro do mensalista antes de transferir.');
 return {...d,sessions:d.sessions.map(v=>v.id===id?{...v,slot:to}:v)};
}
export function setSlot(d:Data,id:string,status:SlotStatus,reservedFor=''):Data {
 if(occupant(d,id)) throw Error('Não é possível alterar uma vaga ocupada.');
 if(status==='reserved'&&!validPlate(reservedFor)) throw Error('Informe a placa para a reserva.');
 return {...d,slots:d.slots.map(s=>s.id===id?{...s,status,reservedFor:status==='reserved'?normalizePlate(reservedFor):undefined}:s)};
}
export function editSession(d:Data,id:string,patch:Pick<Session,'plate'|'model'|'type'|'color'|'owner'|'phone'>):Data {
 const s=d.sessions.find(s=>s.id===id),plate=normalizePlate(patch.plate);
 if(!s||s.exit||s.movement) throw Error('Veículo indisponível para edição.');
 if(!validPlate(plate)||!patch.model.trim()) throw Error('Placa ou modelo inválido.');
 if(present(d).some(v=>v.id!==id&&v.plate===plate)) throw Error('Placa já está presente.');
 if(s.paidMonthly && plate!==s.plate) throw Error('Placa vinculada ao plano mensalista.');
 return {...d,sessions:d.sessions.map(v=>v.id===id?{...v,...patch,plate}:v)};
}
export function saveMember(d:Data,m:Member):Data {
 m={...m,plate:normalizePlate(m.plate)};
 if(!m.name.trim()||!validPlate(m.plate)||!Number.isFinite(m.amount)||m.amount<0||!/^\d{4}-\d{2}-\d{2}$/.test(m.due)||!/^\d{4}-\d{2}-\d{2}$/.test(m.since)) throw Error('Confira nome, placa, datas e mensalidade.');
 if(d.members.some(v=>v.id!==m.id&&v.plate===m.plate)) throw Error('Placa já cadastrada em outro plano.');
 if(m.fixedSlot&&(!d.slots.some(s=>s.id===m.fixedSlot)||d.members.some(v=>v.id!==m.id&&v.active&&v.fixedSlot===m.fixedSlot))) throw Error('Vaga fixa já vinculada ou inválida.');
 return {...d,members:d.members.some(v=>v.id===m.id)?d.members.map(v=>v.id===m.id?m:v):[...d.members,m]};
}
export function receiveMember(d:Data,id:string,method:Payment,now=Date.now()):Data {
 const m=d.members.find(m=>m.id===id);
 if(!m||!m.active) throw Error('Plano inativo.');
 if(m.paid) throw Error('Mensalidade já recebida.');
 return {...d,members:d.members.map(v=>v.id===id?{...v,paid:true}:v),transactions:[...d.transactions,{id:crypto.randomUUID(),memberId:id,at:now,amount:method==='Cortesia'?0:m.amount,method,description:`Mensalidade · ${m.name}`,kind:'Mensalista'}]};
}
export function validateRates(r:Rates) {
 if(![r.firstHour,r.additionalHour,r.tolerance,r.dailyMax,r.monthly,r.specialStart,r.specialEnd,r.specialDiscount].every(Number.isFinite)||r.firstHour<0||r.additionalHour<0||r.tolerance<0||r.dailyMax<r.firstHour||r.monthly<0||r.specialDiscount<0||r.specialDiscount>100||r.specialStart<0||r.specialStart>23||r.specialEnd<0||r.specialEnd>23||!['ceil','proportional'].includes(r.rounding)) throw Error('Tarifas inválidas. A diária deve cobrir a primeira hora e o desconto deve estar entre 0 e 100%.');
}
