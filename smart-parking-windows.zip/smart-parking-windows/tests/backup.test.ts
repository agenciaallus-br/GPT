import { describe,it,expect } from 'vitest';
import { parseBackup } from '../src/store';
import { demo } from '../src/domain';
describe('backup',()=>{
 it('restaura todos os registros de uma exportação válida',()=>{const d=demo();expect(parseBackup(JSON.stringify(d))).toEqual(d);});
 it('rejeita versão inválida e campos ausentes',()=>{expect(()=>parseBackup('{"version":2}')).toThrow();const d=demo();delete (d.sessions[0] as any).plate;expect(()=>parseBackup(JSON.stringify(d))).toThrow();});
 it('rejeita vagas ocupadas em duplicidade e pagamentos adulterados',()=>{const d=demo();d.sessions[0].slot=d.sessions[1].slot;expect(()=>parseBackup(JSON.stringify(d))).toThrow();const other=demo();other.transactions.find(t=>t.sessionId)!.amount=999;expect(()=>parseBackup(JSON.stringify(other))).toThrow();});
});
